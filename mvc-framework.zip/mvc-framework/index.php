<?php

/**
 * Ein kleines simples php mvc framework
 * @author Max Klein <max@kleinleibold.de>
 */

/**
 * Diese Konstante wird in eingebundenen Dateien überprüft um direkten Zugriff zu verhindern.
 */
define('_EXEC', 1);

/**
 * Konstante für das Hauptverzeichnis.
 */
define('PATH_BASE', dirname(__FILE__));

//Die restlichen Konstanten definieren.
require_once PATH_BASE . "/includes/defines.php";

//Enthält die Application-Klasse
require_once PATH_INCLUDES . "/controller.php";
require_once PATH_INCLUDES . "/application.php";

// GET und POST zusammenführen
$request = array_merge($_GET, $_POST);

// Hauptklasse instantiieren
$app = new Application($request);

// Ausgabe des HTML-Codes
echo $app->execute();