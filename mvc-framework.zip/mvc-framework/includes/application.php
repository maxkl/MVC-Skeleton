<?php

/**
 * Um den direkten Zugriff zu verhindern.
 */
defined('_EXEC') or die();

/**
 * Die Hauptklasse.
 *
 * Hier wird entschieden welche/r Controller/Action ausgeführt werden soll
 * und es wird der HTML-Code zusammengestellt
 *
 * @author Max Klein <max@kleinleibold.de>
 */
class Application {

	/**
	 * $request enthält alle GET und POST Parameter
	 *
	 * @var string
	 */
	private $request;

	/**
	 * Der in der URL angegebene Pfad.
	 *
	 * Er enthält Controller, Action und weitere Argumente:
	 * "/controller/action/arg1/arg2/.../argn
	 *
	 * @var string
	 */
	private $path;
	private $route;
	private $controller;

	/**
	 * Hier werden der passende Controller instantiiert und seine passende Methode aufgerufen
	 *
	 * @param array $request Enthält alle GET und POST Parameter
	 */
	public function __construct($request) {
		$this->request = $request;

		// Den angeforderten Pfad aus $request auslesen
		$this->path = isset($this->request['path']) ? $this->request['path'] : "";

		// Controller, Action und Argumente auslesen
		$this->route = new Route($this->path);

		// Pfad zur Datei des Controllers. Der Dateiname muss in Kleinbuchstaben sein!
		// Bsp.: / ... /controllers/home.php
		$controller_file = PATH_CONTROLLERS . "/" . strtolower($this->route->controller) . ".php";

		if (file_exists($controller_file)) {
			// Datei des Controllers einbinden
			require_once $controller_file;

			// Groß-/Kleinschreibung ist egal
			// Bsp.: HomeController
			$controller_class = $this->route->controller . "Controller";

			if (class_exists($controller_class)) {
				// Controller instantiieren
				$this->controller = new $controller_class($this->route);

				// Groß-/Kleinschreibung ist egal
				// Bsp.: IndexAction
				$controller_method = $this->route->action . "Action";

				if (method_exists($this->controller, $controller_method)) {
					// TODO
					$this->controller->$controller_method();
				}
			}
		}
	}

	/**
	 * Erzeugt den endgültigen HTML-Code
	 * @todo Fertig schreiben
	 *
	 * @return string Der HTML-Code
	 */
	public function execute() {
		/*
		$html = "<!DOCTYPE html>";
		$html .= "<html>";
		$html .= "<head>";
		$html .= "</head>";
		$html .= "<body>";
		$html .= "Path: {$this->path}<br />";
		$html .= "Controller: {$this->route->controller}<br />";
		$html .= "Action: {$this->route->action}<br />";
		$html .= "Params:<br />";
		foreach ($this->route->params as $param) {
			$html .= " - $param<br />";
		}
		$html .= "</body>";
		$html .= "</html>";
		return $html;
		*/
	}

}

class Route {

	/**
	 * Wenn Controller und/oder Action nicht angegeben werden,
	 * werden diese Werte benutzt
	 *
	 * @var string
	 */
	private static $default_controller = "home";
	private static $default_action = "index";

	/**
	 * Der Controller der die Anfrage bearbeitet
	 *
	 * @var string
	 */
	public $controller;

	/**
	 * Die Methode des Controllers die die Anfrage bearbeitet
	 *
	 * @var string
	 */
	public $action;

	/**
	 * Alle weiteren Argumente aus $path
	 *
	 * @var array
	 */
	public $params;

	/**
	 *
	 * @param string $controller
	 * @param string $action
	 * @param string $params
	 */
	public function __construct($path) {
		$this->route($path);
	}

	/**
	 * Extrahiert Controller, Action und Argumente aus $path
	 */
	private function route($path) {
		$path = preg_replace("(^/+|/+$|\s)", "", $path);
		$path = preg_replace("(/+)", "/", $path);

		$parts = ($path !== "") ? explode("/", $path) : array();
		$this->controller = count($parts) >= 1 ? $parts[0] : self::$default_controller;
		$this->action = count($parts) >= 2 ? $parts[1] : self::$default_action;
		$this->params = count($parts) >= 3 ? array_slice($parts, 2) : array();
	}

}
